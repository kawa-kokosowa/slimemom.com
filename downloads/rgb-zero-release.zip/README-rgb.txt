RGB (Red Green Blue)
(C) Copyright 2015 Lillian Lynn Lemmer. this game is distributed under
the terms of the MIT license.

A cute game :3

http://about.lillian.link
lillian.lynn.lemmer@gmail.com
